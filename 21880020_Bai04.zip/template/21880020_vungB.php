<?php
  echo '
    <div class="" id="avatar">
      
    </div>
  '; 
?>
