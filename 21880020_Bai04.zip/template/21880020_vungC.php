<?php echo '
      <div class="col-4" id="left">
        <ul><a href="../index.php">Trang chủ</a></ul>
        <ul><a href="../21880020_Bai01/index.php">Bài 01</a></ul>
        <ul><a href="../21880020_Bai02/index.php">Bài 02</a></ul>
        <ul><a href="../21880020_Bai03/index.php">Bài 03</a></ul>
        <ul><a href="../21880020_Bai04/index.php">Bài 04</a></ul>
        <ul><a href="../21880020_Bai05/index.php">Bài 05</a></ul>
        <ul><a href="../21880020_Bai06/index.php">Bài 06</a></ul>
        <ul><a href="../21880020_Bai07/index.php">Bài 07</a></ul>
        <ul><a href="../21880020_Bai08/index.php">Bài 08</a></ul>
        <ul><a href="../21880020_Bai09/index.php">Bài 09</a></ul>
        <ul><a href="../21880020_Bai10/index.php">Bài 10</a></ul>
        <ul><a href="../21880020_Bai11/index.php">Bài 11</a></ul>
        <ul><a href="../21880020_Bai12/index.php">Bài 12</a></ul>
        <ul><a href="../21880020_Bai13/index.php">Bài 13</a></ul>
      </div>
      ';
?>
      