<?php echo '
        <div class="w-100" id="footer">
            <p>&copy {'.date("Y").'} 21880020 - Nguyễn Công Danh - nguyencongdanh2410@gmail.com</p>
        </div>
        ';
?>      